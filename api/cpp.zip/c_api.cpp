#include "c_api.h"
#pragma warning(disable:4996)

std::string c_api::api = "http://localhost/api/";
std::string c_api::token = "";

bool c_api::c_login(std::string c_username, std::string c_password, std::string c_hwid) {
	if (c_hwid == "meme") c_hwid = ReqUtils::serial();
	
	http::post_data values = {
		{"username", base64_encode(c_aesar::encipher(base64_encode(c_username), 8))},
		{"password", base64_encode(c_aesar::encipher(base64_encode(c_password), 8))},
		{"hwid", base64_encode(c_aesar::encipher(base64_encode(c_hwid), 8))}
	};

	std::string result = base64_decode(c_aesar::decipher(base64_decode(http::post(api + "c_handle.php?m=a", values)->text), 8));

	if (result == "") 
	{
		MessageBox(0, L"empty_response", L"", MB_OK);
		return false;
	}
	else if (result == "empty_username")
	{
		MessageBox(0, L"empty_username", L"", MB_OK);
		return false;
	}
	else if (result == "invalid_username")
	{
		MessageBox(0, L"invalid_username", L"", MB_OK);
		return false;
	}
	else if (result == "empty_password")
	{
		MessageBox(0, L"empty_password", L"", MB_OK);
		return false;
	}
	else if (result == "wrong_password")
	{
		MessageBox(0, L"wrong_password", L"", MB_OK);
		return false;
	}
	else if (result == "no_sub")
	{
		MessageBox(0, L"no_sub", L"", MB_OK);
		return false;
	}
	else if (result == "wrong_hwid")
	{
		MessageBox(0, L"wrong_hwid", L"", MB_OK);
		return false;
	}
	else if(result.find("logged_in") != std::string::npos)
	{
		std::vector<std::string> x_x = x_spliter::split(result, '|');
		token = x_x[1];

		return true;
	}
	else {
		MessageBox(0, L"unknown_response", L"", MB_OK);
		return false;
	}
}
  
char* c_api::c_dll() {
	return (char*)http::post(api + "c_download.php", http::post_data{ {"t", base64_encode(c_aesar::encipher(base64_encode(token), 8))} })->text.c_str();
}