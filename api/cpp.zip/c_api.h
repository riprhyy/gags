#include "http/utils.h"
#include "http/http.h"
#include "c_utils.h"
#include "base64.h"
#include "caesar.h"
#include "split.h"


class c_api 
{
public:
    static bool c_login(std::string c_username, std::string c_password, std::string c_hwid = "meme");
	static char* c_dll();
	static std::string token;
private:
	static std::string api;
};